package com.bms.placement.company;
//ResponseEntity class will receive the request and process it further.
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.persistence.NoResultException;

@RestController
public class CompanyController {

	@Autowired  // Multiple objects can be created by java beans
	private CompanyService service;
	
	@GetMapping("/companyservice")
	public List<Company> list()
	{
		return service.listAllRecords();
	}
	
	@PostMapping("/companyservice")
	public void add(@RequestBody Company cust)
	{
		service.insertRecord(cust);
	}
	
	@GetMapping("/companyservice/{id}")
	public ResponseEntity<Company> get(@PathVariable Integer id)
	{
		try
		{
			Company cust=service.getParticularRecord(id);
			return new ResponseEntity<Company>(cust,HttpStatus.OK);
		}
		catch(NoResultException e)
		{
			return new ResponseEntity<Company>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/companyservice/{id}")
	public void delete(@PathVariable Integer id)
	{
		service.delete(id);
	}
	
	 @PutMapping("/companyservice/{id}")
	 public ResponseEntity<Void> updateCompany(@PathVariable Integer id, @RequestBody Company updatedCompany) 
	 {   
		 updatedCompany.setCid(id);
	     service.update(updatedCompany);
	     return new ResponseEntity<Void>(HttpStatus.OK);
	  }
	
	
}