package com.bms.placement.company;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity  //this will create a table in database
public class Company {
	@Id
	private int cid;
	private String cname;
	private String industry;
	private String location;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Company [cid=" + cid + ", cname=" + cname + ", industry=" + industry + ", location=" + location + "]";
	}
	
}
