package com.bms.placement.company;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CompanyService {
	
	@Autowired
	private CompanyRepository repo;	
	//Insert the record into the database
	public void insertRecord(Company com)
	{
		repo.save(com);
	}
	
	//Get all the records from the table
	public List<Company> listAllRecords()
	{
		return repo.findAll();
	}
	
	//Retrieving the particular record
	public Company getParticularRecord(Integer id)
	{
		return repo.findById(id).get();
	}
	
	//Deleting the record method
	public void delete(Integer id)
	{
		repo.deleteById(id);
	}
	
	//Update the record
	public void update(Company updatedCompany) {
	    if(repo.existsById(updatedCompany.getCid())) {	        
	        Company existingCustomer = repo.findById(updatedCompany.getCid()).get();
	        existingCustomer.setCname(updatedCompany.getCname());
	        existingCustomer.setIndustry(updatedCompany.getIndustry());

	        existingCustomer.setLocation(updatedCompany.getLocation());
	        repo.save(existingCustomer);
	    } else {
	        
	        System.out.println("Company with ID " + updatedCompany.getCid() + " not found. Cannot update.");
	    }
	}

	
	
	
}